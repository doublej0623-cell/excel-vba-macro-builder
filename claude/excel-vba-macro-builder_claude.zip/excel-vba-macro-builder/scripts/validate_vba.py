#!/usr/bin/env python3
"""Conservative structural/safety validator for generated Excel VBA .bas modules.

This is a release-gate helper, not a replacement for native VBA compilation.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path


def read_text(path: Path) -> tuple[str, str]:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp949", "cp1252", "latin-1"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            pass
    raise UnicodeDecodeError("unknown", raw, 0, 1, "unsupported encoding")


def strip_comment(line: str) -> str:
    out: list[str] = []
    in_string = False
    i = 0
    while i < len(line):
        ch = line[i]
        if ch == '"':
            if in_string and i + 1 < len(line) and line[i + 1] == '"':
                out.extend(['"', '"'])
                i += 2
                continue
            in_string = not in_string
            out.append(ch)
        elif ch == "'" and not in_string:
            break
        else:
            out.append(ch)
        i += 1
    return "".join(out).strip()


def body_for_proc(text: str, name: str) -> str:
    pattern = re.compile(
        rf"(?ims)^\s*(?:Public\s+|Private\s+|Friend\s+|Static\s+)?Sub\s+{re.escape(name)}\b.*?^\s*End\s+Sub\b"
    )
    m = pattern.search(text)
    return m.group(0) if m else ""


def procedure_records(text: str) -> list[dict[str, str]]:
    pattern = re.compile(
        r"(?im)^\s*(?:(Public|Private|Friend|Static)\s+)?(Sub|Function)\s+([A-Za-z_][A-Za-z0-9_]*)\s*(?:\(([^)]*)\))?"
    )
    records: list[dict[str, str]] = []
    for access, kind, name, params in pattern.findall(text):
        records.append(
            {
                "access": access or "",
                "kind": kind,
                "name": name,
                "params": (params or "").strip(),
            }
        )
    return records


def check_application_state_restore(text: str, prop: str, disabling_pattern: str) -> bool:
    """Return True when a property appears changed and never visibly restored/reassigned."""
    if not re.search(disabling_pattern, text, re.I):
        return False
    assigns = re.findall(rf"(?i)Application\.{re.escape(prop)}\s*=\s*([^:\r\n]+)", text)
    if len(assigns) < 2:
        return True
    disabling_rhs = re.compile(disabling_pattern.split("=", 1)[1].strip(), re.I) if "=" in disabling_pattern else None
    if disabling_rhs is None:
        return False
    return all(disabling_rhs.search(rhs.strip()) for rhs in assigns)


def validate(text: str) -> dict:
    errors: list[str] = []
    warnings: list[str] = []

    if not re.search(r'(?im)^\s*Attribute\s+VB_Name\s*=\s*"[^"]+"', text):
        errors.append("Attribute VB_Name is missing.")
    if not re.search(r"(?im)^\s*Option\s+Explicit\s*$", text):
        errors.append("Option Explicit is missing.")
    if re.search(r"(?i)\bTODO\b|<TODO>|\[TODO\]|\.\.\.", text):
        errors.append("Placeholder/TODO text remains in the module.")

    procs = procedure_records(text)
    names = [p["name"].lower() for p in procs]
    duplicates = sorted({n for n in names if names.count(n) > 1})
    if duplicates:
        errors.append("Duplicate procedure names: " + ", ".join(duplicates))

    for required in ("runautomation", "setuprunbutton"):
        matches = [p for p in procs if p["name"].lower() == required]
        if not matches:
            errors.append(f"Required procedure is missing: {required}")
            continue
        p = matches[0]
        if p["kind"].lower() != "sub":
            errors.append(f"Required entry point must be a Sub: {p['name']}")
        if p["params"]:
            errors.append(f"Required entry point must have no parameters: {p['name']}")
        if p["access"].lower() == "private":
            errors.append(f"Required entry point must not be Private: {p['name']}")

    setup = body_for_proc(text, "SetupRunButton")
    if setup:
        if not re.search(r"(?i)\.OnAction\s*=", setup):
            errors.append("SetupRunButton does not assign a button OnAction.")
        if not re.search(r"(?i)\.OnAction\s*=.*RunAutomation", setup):
            errors.append("SetupRunButton OnAction does not visibly reference RunAutomation.")
        if re.search(r"(?i)OLEObjects\.Add|Forms\.CommandButton|CommandButton", setup):
            warnings.append("SetupRunButton appears to use ActiveX/CommandButton; shape buttons are preferred.")
        if not re.search(r"(?i)Shapes\s*\(|Shapes\.AddShape|For\s+Each\s+\w+\s+In\s+.*Shapes", setup):
            warnings.append("Could not confirm shape-button duplicate handling in SetupRunButton.")

    run = body_for_proc(text, "RunAutomation")
    if run and not re.search(r"(?i)On\s+Error\s+GoTo", run):
        warnings.append("RunAutomation has no visible On Error GoTo handler.")

    pairs = [
        (r"(?im)^\s*(?:Public\s+|Private\s+|Friend\s+|Static\s+)?Sub\b", r"(?im)^\s*End\s+Sub\b", "Sub/End Sub"),
        (r"(?im)^\s*(?:Public\s+|Private\s+|Friend\s+|Static\s+)?Function\b", r"(?im)^\s*End\s+Function\b", "Function/End Function"),
        (r"(?im)^\s*Select\s+Case\b", r"(?im)^\s*End\s+Select\b", "Select Case/End Select"),
        (r"(?im)^\s*With\b", r"(?im)^\s*End\s+With\b", "With/End With"),
        (r"(?im)^\s*Do(?:\s|$)", r"(?im)^\s*Loop(?:\s|$)", "Do/Loop"),
        (r"(?im)^\s*While\b", r"(?im)^\s*Wend\b", "While/Wend"),
    ]
    for start, end, label in pairs:
        a = len(re.findall(start, text))
        b = len(re.findall(end, text))
        if a != b:
            errors.append(f"Unbalanced {label}: {a} start(s), {b} end(s).")

    block_if = 0
    end_if = 0
    for raw in text.splitlines():
        line = strip_comment(raw)
        if not line:
            continue
        if re.match(r"(?i)^If\b.*\bThen\s*$", line):
            block_if += 1
        if re.match(r"(?i)^End\s+If\b", line):
            end_if += 1
    if block_if != end_if:
        errors.append(f"Unbalanced block If/End If: {block_if} start(s), {end_if} end(s).")

    for_count = 0
    next_count = 0
    for raw in text.splitlines():
        line = strip_comment(raw)
        if re.match(r"(?i)^For\s+(?:Each\s+)?[A-Za-z_]", line):
            for_count += 1
        if re.match(r"(?i)^Next(?:\s|$)", line):
            next_count += 1
    if for_count != next_count:
        errors.append(f"Unbalanced For/Next: {for_count} start(s), {next_count} end(s).")

    state_rules = [
        ("ScreenUpdating", r"Application\.ScreenUpdating\s*=\s*False"),
        ("EnableEvents", r"Application\.EnableEvents\s*=\s*False"),
        ("DisplayAlerts", r"Application\.DisplayAlerts\s*=\s*False"),
        ("Calculation", r"Application\.Calculation\s*=\s*xlCalculationManual"),
    ]
    for prop, disabling in state_rules:
        if check_application_state_restore(text, prop, disabling):
            errors.append(f"Application.{prop} is changed but no visible restore/reassignment was found.")

    if re.search(r"(?im)^\s*(?:Range|Cells|Rows|Columns)\s*\(", text):
        warnings.append("Unqualified Range/Cells/Rows/Columns reference found; verify workbook/worksheet qualification.")
    if re.search(r"(?i)\bActiveWorkbook\b|\bActiveSheet\b", text):
        warnings.append("ActiveWorkbook/ActiveSheet usage found; verify that it cannot target the wrong workbook/sheet.")
    if re.search(r"(?i)\.Select\b|\.Activate\b", text):
        warnings.append("Select/Activate usage found; verify it is necessary and safe.")
    if re.search(r"(?im)^\s*On\s+Error\s+Resume\s+Next\b", text):
        warnings.append("On Error Resume Next found; scope it narrowly and restore normal error handling immediately.")
    if re.search(r"(?im)^\s*End\s*$", text):
        warnings.append("Bare End statement found; it can bypass cleanup and leave Excel state inconsistent.")

    dangerous_patterns = [
        (r"(?im)^\s*Kill\s+", "Kill statement found; verify deletion is explicitly required and safely scoped."),
        (r"(?im)^\s*RmDir\s+", "RmDir found; verify folder deletion is explicitly required and safely scoped."),
        (r"(?i)\.DeleteFile\b|\.DeleteFolder\b", "File/folder deletion API found; verify deletion is explicitly required and safely scoped."),
        (r"(?im)^\s*Shell\s*\(", "Shell execution found; verify external process execution is necessary and safe."),
        (r"(?i)WScript\.Shell|CreateObject\s*\(\s*\"WScript\.Shell\"", "WScript.Shell found; verify external shell access is necessary."),
        (r"(?i)VBProject\b|VBComponents\b", "VBProject/VBComponents access found; self-modifying VBA requires explicit justification."),
    ]
    for pattern, message in dangerous_patterns:
        if re.search(pattern, text):
            warnings.append(message)

    if re.search(r"(?im)^\s*(?:Private\s+|Public\s+)?Declare\s+", text) and not re.search(r"(?i)\bPtrSafe\b", text):
        warnings.append("Windows API Declare found without visible PtrSafe; verify 64-bit Office compatibility or conditional compilation.")

    if re.search(r'(?i)"[A-Za-z]:\\[^"\r\n]+"', text):
        warnings.append("Hard-coded absolute Windows path found; prefer configurable or workbook-relative paths where appropriate.")

    return {
        "errors": errors,
        "warnings": warnings,
        "procedures": [p["name"] for p in procs],
        "note": "Structural/safety checks only; native VBA compilation/runtime validation is still required when available.",
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("bas_file")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    path = Path(args.bas_file)
    if not path.is_file():
        print(f"ERROR: file not found: {path}", file=sys.stderr)
        return 2

    text, encoding = read_text(path)
    result = validate(text)
    result["file"] = str(path)
    result["encoding"] = encoding
    result["status"] = "PASS" if not result["errors"] else "FAIL"

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"{result['status']}: {path} ({encoding})")
        for e in result["errors"]:
            print(f"ERROR: {e}")
        for w in result["warnings"]:
            print(f"WARNING: {w}")
        print("Procedures:", ", ".join(result["procedures"]) or "none")
        print("NOTE:", result["note"])

    return 0 if not result["errors"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
