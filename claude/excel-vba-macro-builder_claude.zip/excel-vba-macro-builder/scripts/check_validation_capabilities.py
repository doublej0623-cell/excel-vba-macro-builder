#!/usr/bin/env python3
"""Report which native/auxiliary VBA validation capabilities are locally available.

This script only detects capabilities. It does not launch Excel or install anything.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import platform
import shutil
import subprocess
from pathlib import Path


def command_version(path: str) -> str | None:
    probes = ([path, "--version"], [path, "-v"])
    for cmd in probes:
        try:
            cp = subprocess.run(cmd, capture_output=True, text=True, timeout=5, check=False)
        except (OSError, subprocess.SubprocessError):
            continue
        out = (cp.stdout or cp.stderr).strip().splitlines()
        if out:
            return out[0][:200]
    return None


def find_excel_windows() -> str | None:
    if platform.system().lower() != "windows":
        return None
    candidates = []
    for env_name in ("ProgramFiles", "ProgramFiles(x86)"):
        base = os.environ.get(env_name)
        if not base:
            continue
        for office in ("root/Office16", "Office16", "Microsoft Office/root/Office16"):
            candidates.append(Path(base) / "Microsoft Office" / office / "EXCEL.EXE")
        candidates.append(Path(base) / "Microsoft Office" / "root" / "Office16" / "EXCEL.EXE")
    for p in candidates:
        if p.is_file():
            return str(p)
    return shutil.which("EXCEL.EXE")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    xlflow = shutil.which("xlflow")
    excel = find_excel_windows()
    pywin32 = importlib.util.find_spec("win32com") is not None
    windows = platform.system().lower() == "windows"

    result = {
        "platform": platform.platform(),
        "windows": windows,
        "excel_executable": excel,
        "pywin32_available": pywin32,
        "xlflow_path": xlflow,
        "xlflow_version": command_version(xlflow) if xlflow else None,
        "native_excel_candidate": bool(windows and (excel or pywin32)),
        "guidance": [],
    }

    if result["native_excel_candidate"]:
        result["guidance"].append("Native Excel validation may be possible; use a temporary workbook copy and verify actual execution.")
    else:
        result["guidance"].append("Native Excel validation is not detected; perform all non-Excel validation and report the limitation.")
    if xlflow:
        result["guidance"].append("xlflow is available; inspect its current --help and use supported validation commands as an additional layer.")
    else:
        result["guidance"].append("xlflow is not detected; do not require installation and continue with available validation methods.")

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Platform: {result['platform']}")
        print(f"Windows: {result['windows']}")
        print(f"Excel executable: {result['excel_executable'] or 'not detected'}")
        print(f"pywin32: {'available' if result['pywin32_available'] else 'not detected'}")
        print(f"xlflow: {result['xlflow_path'] or 'not detected'}")
        if result["xlflow_version"]:
            print(f"xlflow version: {result['xlflow_version']}")
        print(f"Native Excel candidate: {result['native_excel_candidate']}")
        for item in result["guidance"]:
            print(f"- {item}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
